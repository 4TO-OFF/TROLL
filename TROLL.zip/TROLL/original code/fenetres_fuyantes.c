#include <windows.h>
#include <stdlib.h>
#include <time.h>

#define MAX_X 1920 // Largeur de l'écran (ajuste selon ta résolution)
#define MAX_Y 1080 // Hauteur de l'écran (ajuste selon ta résolution)

HWND hwndGlobal; // Fenêtre globale pour pouvoir y accéder dans le callback

// Fonction de gestion de la fenêtre
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

int main() {
    srand(time(NULL));

    // 1. Créer la fenêtre
    WNDCLASS wc = {0};
    wc.lpfnWndProc = WindowProc;
    wc.lpszClassName = "FuyantesClass";
    wc.hInstance = GetModuleHandle(NULL);

    RegisterClass(&wc);

    hwndGlobal = CreateWindowEx(
        0,
        wc.lpszClassName,
        "Ferme moi si tu peux >:)",  // Titre de la fenêtre
        WS_OVERLAPPEDWINDOW,
        100, 100, 400, 200,  // Position et taille de la fenêtre
        NULL, NULL, wc.hInstance, NULL
    );

    if (hwndGlobal == NULL) {
        MessageBox(NULL, "Échec de la création de la fenêtre", "Erreur", MB_OK | MB_ICONERROR);
        return 1;
    }

    ShowWindow(hwndGlobal, SW_SHOW);
    UpdateWindow(hwndGlobal);

    // 2. Obtenir la taille de l'écran
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // 3. Boucle principale
    MSG msg;
    while (1) {
        // Vérifier les messages de la fenêtre pour permettre les interactions
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) {
                break;
            }
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        // Vérifier si le curseur est au-dessus de la fenêtre
        RECT rect;
        if (GetWindowRect(hwndGlobal, &rect)) {
            POINT cursor;
            GetCursorPos(&cursor);

            // Vérifier si le curseur est dans la fenêtre
            if (cursor.x >= rect.left && cursor.x <= rect.right && cursor.y >= rect.top && cursor.y <= rect.bottom) {
                // Déplacer la fenêtre si le curseur est dessus
                int newX = rand() % (screenWidth - rect.right); // Ne pas dépasser la largeur de l'écran
                int newY = rand() % (screenHeight - rect.bottom); // Ne pas dépasser la hauteur de l'écran

                // Déplacer la fenêtre à la nouvelle position
                SetWindowPos(hwndGlobal, NULL, newX, newY, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
            }
        }

        // Attendre 20ms avant de refaire la vérification
        Sleep(20);  // 20ms
    }

    return 0;
}
