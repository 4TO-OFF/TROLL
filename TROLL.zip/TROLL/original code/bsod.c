#include <windows.h>
#include <mmsystem.h>

void SetVolumeToZero() {
    // Définit le volume à 0
    DWORD dwVolume = 0;
    waveOutSetVolume(NULL, dwVolume);
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_CREATE:
            SetVolumeToZero();  // Appelle pour couper le son au démarrage
            break;
        case WM_CLOSE:
        case WM_DESTROY:
            return 0; // Bloque la fermeture
        case WM_KEYDOWN:
            if (wParam == VK_ESCAPE || wParam == VK_F4) return 0; // Bloque Échap et Alt+F4
            break;
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);
            
            // Fond bleu du BSOD
            HBRUSH blueBrush = CreateSolidBrush(RGB(0, 0, 255));
            FillRect(hdc, &ps.rcPaint, blueBrush);
            DeleteObject(blueBrush);
            
            // Texte en blanc
            SetTextColor(hdc, RGB(255, 255, 255));
            SetBkMode(hdc, TRANSPARENT);
            HFONT font = CreateFont(30, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                                    OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                                    VARIABLE_PITCH, TEXT("Consolas"));
            SelectObject(hdc, font);
            
            const char* bsodText = 
                ":("
                "Un problème a été détecté et Windows a été arrêté pour éviter\n"
                "d'endommager votre ordinateur.\n\n"
                "PAGE_FAULT_IN_NONPAGED_AREA\n\n"
                "Si c'est la première fois que vous voyez cet écran,\n"
                "redémarrez votre ordinateur.\n"
                "Si ce problème persiste, contactez votre administrateur système.";

            RECT rect;
            GetClientRect(hwnd, &rect);
            DrawText(hdc, bsodText, -1, &rect, DT_CENTER | DT_VCENTER | DT_WORDBREAK);

            DeleteObject(font);
            EndPaint(hwnd, &ps);
        } break;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    const char CLASS_NAME[] = "FakeBSOD";

    WNDCLASS wc = { };
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;

    RegisterClass(&wc);

    HWND hwnd = CreateWindowEx(
        WS_EX_TOPMOST, CLASS_NAME, "BSOD",
        WS_POPUP, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),
        NULL, NULL, hInstance, NULL);

    ShowWindow(hwnd, SW_SHOW);
    UpdateWindow(hwnd);

    MSG msg = { };
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}
