#include <stdio.h>
#include <unistd.h>  // Pour usleep()
#include <stdlib.h>  // Pour system()

int main() {
    printf("AVERTISSEMENT : Tous les fichiers sur le disque C: seront perdus !\n");
    usleep(3000000);  // Pause de 3 secondes
    printf("Voulez-vous continuer ? (O/N)\n");
    usleep(2000000);  // Pause de 2 secondes
    printf("O\n");
    usleep(1000000);  // Pause de 1 secondes

    // Formatage progressif
    printf("Formatage en cours...\n");
    
    // 0% à 70% en 5 secondes
    for (int i = 0; i <= 70; i++) {
        printf("Formatage à %d%%...\n", i);
        usleep(71428);  // 5 secondes / 70 % = 71428 microsecondes par % (~0.07 sec par %)
    }
    usleep(1000000);  // Pause de 1 seconde entre les paliers

    // 70% à 85% en 1 seconde
    for (int i = 71; i <= 85; i++) {
        printf("Formatage à %d%%...\n", i);
        usleep(66667);  // 1 seconde / 15 % = 66667 microsecondes par %
    }
    usleep(1000000);  // Pause de 1 seconde entre les paliers

    // 85% à 99% en 2 secondes
    for (int i = 86; i <= 99; i++) {
        printf("Formatage à %d%%...\n", i);
        usleep(13333);  // 2 secondes / 15 % = 13333 microsecondes par %
    }
    usleep(1000000);  // Pause de 1 seconde entre les paliers

    // 99% à 100% en 7 secondes
    for (int i = 100; i > 99; i--) {
        printf("Formatage à %d%%...\n", i);
        usleep(700000);  // 7 secondes / 1 % = 700000 microsecondes
    }

    printf("Formatage terminé !\n");
    usleep(8000000);  // Pause de 7 secondes
    printf("... Nan j'déconne, tout va bien :D\n");

    // Attendre une entrée utilisateur avant de fermer
    system("pause");

    return 0;
}
