#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>

#define NUM_MOVES 50 // Nombre de déplacements à faire

// Fonction pour déplacer la souris
void moveMouseRandomly() {
    // Obtenez les dimensions de l'écran
    RECT desktop;
    const HWND hDesktop = GetDesktopWindow();
    GetWindowRect(hDesktop, &desktop);

    int screenWidth = desktop.right;
    int screenHeight = desktop.bottom;

    // Générer des coordonnées aléatoires dans les limites de l'écran
    int x = rand() % screenWidth;
    int y = rand() % screenHeight;

    // Déplacer la souris
    SetCursorPos(x, y);
}

int main() {
    srand(time(NULL)); // Initialiser le générateur de nombres aléatoires

    // Déplacer la souris de manière aléatoire plusieurs fois
    for (int i = 0; i < NUM_MOVES; i++) {
        moveMouseRandomly(); // Déplacer la souris
        Sleep(100); // Attendre un peu avant de déplacer à nouveau
    }

    return 0;
}
