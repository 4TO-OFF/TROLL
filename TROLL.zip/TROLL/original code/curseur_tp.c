#include <windows.h>
#include <stdlib.h>
#include <time.h>

int main() {
    // Cache la console au démarrage
    HWND hWnd = GetConsoleWindow();
    ShowWindow(hWnd, SW_HIDE);

    POINT p;
    srand(time(NULL));

    while (1) {
        GetCursorPos(&p);

        int moveX = (rand() % 30) - 15;
        int moveY = (rand() % 30) - 15;

        if (rand() % 4 == 0) {
            moveX *= -1;
            moveY *= -1;
        }
        if (rand() % 6 == 0) {
            moveX *= 2;
            moveY *= 2;
        }
        if (rand() % 10 == 0) {
            Sleep(1000);
        }
        if (rand() % 15 == 0) {
            int screenX = GetSystemMetrics(SM_CXSCREEN);
            int screenY = GetSystemMetrics(SM_CYSCREEN);
            int newX = rand() % screenX;
            int newY = rand() % screenY;
            SetCursorPos(newX, newY);
        } else {
            SetCursorPos(p.x - moveX, p.y - moveY);
        }

        Sleep(10);
    }

    return 0;
}
