#include <windows.h>
#include <stdlib.h>
#include <time.h>

#define INIT_WIDTH 300
#define INIT_HEIGHT 150
#define MAX_SPEED 20  // Vitesse maximale des fenêtres clones

typedef struct {
    int dx, dy;  // Vitesse de la fenêtre
    HWND hwnd;   // Handle de la fenêtre
    BOOL isFirst;  // Indique si c'est la première fenêtre
} WindowData;

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void SpawnWindows(int count);
void CheckCollisions();

HINSTANCE g_hInstance;
WindowData* g_windowData = NULL;
int g_windowCount = 0;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    g_hInstance = hInstance;
    
    WNDCLASS wc = {0};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = "ChaosWindow";
    
    RegisterClass(&wc);
    
    // Crée la première fenêtre au centre de l'écran
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    HWND hwnd = CreateWindowEx(
        0, "ChaosWindow", "Ne me ferme pas :) Je suis gentil",
        WS_OVERLAPPEDWINDOW, (screenWidth - INIT_WIDTH) / 2, (screenHeight - INIT_HEIGHT) / 2, INIT_WIDTH, INIT_HEIGHT,
        NULL, NULL, hInstance, NULL
    );
    
    // Définir la première fenêtre comme immobile et l'ajouter à la liste
    g_windowCount++;
    g_windowData = realloc(g_windowData, g_windowCount * sizeof(WindowData));
    g_windowData[g_windowCount - 1].hwnd = hwnd;
    g_windowData[g_windowCount - 1].isFirst = TRUE;
    ShowWindow(hwnd, SW_SHOW);
    
    // Afficher la première fenêtre sans mouvement
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    
    return 0;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    static RECT screen;
    static BOOL moving = FALSE;

    switch (uMsg) {
        case WM_CREATE:
            GetWindowRect(hwnd, &screen);
            // Ajouter la fenêtre à la liste
            g_windowCount++;
            g_windowData = realloc(g_windowData, g_windowCount * sizeof(WindowData));
            g_windowData[g_windowCount - 1].hwnd = hwnd;
            // Vitesse aléatoire pour chaque fenêtre
            g_windowData[g_windowCount - 1].dx = (rand() % 2 == 0 ? 1 : -1) * (rand() % 5 + 5);
            g_windowData[g_windowCount - 1].dy = (rand() % 2 == 0 ? 1 : -1) * (rand() % 5 + 5);
            g_windowData[g_windowCount - 1].isFirst = FALSE;
            SetTimer(hwnd, g_windowCount, 30, NULL);  // Timer unique pour chaque fenêtre, sauf la première
            break;
        
        case WM_CLOSE:
            // Crée deux clones lorsque cette fenêtre est fermée
            SpawnWindows(2);
            DestroyWindow(hwnd);
            return 0;

        case WM_TIMER: {
            // Déplacement indépendant pour chaque fenêtre
            for (int i = 0; i < g_windowCount; i++) {
                if (g_windowData[i].hwnd == hwnd) {
                    GetWindowRect(hwnd, &screen);
                    int width = screen.right - screen.left;
                    int height = screen.bottom - screen.top;

                    // Rebond sur les bords
                    if (screen.left <= 0 || screen.right >= GetSystemMetrics(SM_CXSCREEN)) 
                        g_windowData[i].dx = -g_windowData[i].dx;
                    if (screen.top <= 0 || screen.bottom >= GetSystemMetrics(SM_CYSCREEN)) 
                        g_windowData[i].dy = -g_windowData[i].dy;

                    // Déplace la fenêtre
                    SetWindowPos(hwnd, NULL, screen.left + g_windowData[i].dx, screen.top + g_windowData[i].dy, width, height, SWP_NOZORDER | SWP_NOSIZE);
                    
                    // Vérifier les collisions entre les fenêtres (enlevé pour ne plus les faire rebondir)
                    // CheckCollisions();
                    break;
                }
            }
            break;
        }

        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);
            if (!g_windowData[g_windowCount - 1].isFirst) {
                SetTextColor(hdc, RGB(255, 0, 0)); // Couleur rouge pour le texte
                SetBkMode(hdc, TRANSPARENT);
                HFONT font = CreateFont(24, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                                        OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                                        VARIABLE_PITCH, TEXT("Arial"));
                SelectObject(hdc, font);
                RECT rect;
                GetClientRect(hwnd, &rect);
                DrawText(hdc, ">:(", -1, &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                DeleteObject(font);
            }
            EndPaint(hwnd, &ps);
        } break;

        case WM_DESTROY:
            return 0;
    }
    
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

void SpawnWindows(int count) {
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    for (int i = 0; i < count; i++) {
        // Génère des coordonnées aléatoires dans la largeur et la hauteur de l'écran
        int randX = rand() % (screenWidth - INIT_WIDTH);  // Position X aléatoire
        int randY = rand() % (screenHeight - INIT_HEIGHT);  // Position Y aléatoire

        HWND hwnd = CreateWindowEx(
            0, "ChaosWindow", "Pourquoi m'as-tu fermé >:(",
            WS_OVERLAPPEDWINDOW, randX, randY, INIT_WIDTH, INIT_HEIGHT,
            NULL, NULL, g_hInstance, NULL
        );
        
        // Ajouter la nouvelle fenêtre à la liste avec des vitesses aléatoires
        g_windowCount++;
        g_windowData = realloc(g_windowData, g_windowCount * sizeof(WindowData));
        g_windowData[g_windowCount - 1].hwnd = hwnd;
        g_windowData[g_windowCount - 1].dx = (rand() % 2 == 0 ? 1 : -1) * (rand() % 5 + 5);
        g_windowData[g_windowCount - 1].dy = (rand() % 2 == 0 ? 1 : -1) * (rand() % 5 + 5);
        g_windowData[g_windowCount - 1].isFirst = FALSE;

        SetTimer(hwnd, g_windowCount, 30, NULL);  // Timer unique pour chaque clone
        ShowWindow(hwnd, SW_SHOW);
    }
}

// Vérifie les collisions entre les fenêtres clones
void CheckCollisions() {
    // Enlevé le rebond entre fenêtres
    // Ce code a été supprimé pour ne pas rebondir les fenêtres entre elles
}