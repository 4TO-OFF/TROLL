#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>

// Fonction pour simuler l'affichage d'un message d'erreur
void showErrorMessage() {
    MessageBox(NULL, "ATTENTION VOTRE PC EST EN TRAIN DE SE FAIRE PIRATER", "Erreur", MB_ICONERROR);
}

// Fonction pour afficher le message "Vous avez été hacké"
void showHackMessage() {
    MessageBox(NULL, "Vous avez été hacké >:)", "Erreur", MB_ICONERROR);
}

// Fonction pour afficher les fenêtres pop-up avec des tailles plus grandes
void showPopupMessage() {
    // Crée une fenêtre pop-up de taille 500x300 à une position aléatoire
    HWND hwnd = CreateWindowEx(0, "STATIC", "T'es hacker haha", WS_OVERLAPPEDWINDOW, 100, 100, 500, 300, NULL, NULL, NULL, NULL);
    ShowWindow(hwnd, SW_SHOW);
    // Pas de DestroyWindow ici, donc la fenêtre restera ouverte
}

int main() {
    srand(time(NULL)); // Initialiser le générateur de nombres aléatoires

    // Afficher 4 messages d'erreur
    for (int i = 0; i < 4; i++) {
        showErrorMessage();
        Sleep(1000); // Pause de 1 seconde entre chaque message
    }

    // Afficher le message indiquant que le PC est hacké
    showHackMessage();
    Sleep(5000); // Pause de 5 secondes pour laisser le message visible

    // Afficher les fenêtres pop-up à intervalle de 0,2 secondes avec des positions aléatoires
    while (1) { // Utiliser une boucle infinie pour faire apparaître les fenêtres sans fin
        int x = rand() % 1366; // Position X aléatoire (en pixels, à adapter selon la résolution)
        int y = rand() % 768;  // Position Y aléatoire (en pixels, à adapter selon la résolution)

        HWND hwnd = CreateWindowEx(0, "STATIC", "T'es hacker haha", WS_OVERLAPPEDWINDOW, x, y, 500, 300, NULL, NULL, NULL, NULL);
        ShowWindow(hwnd, SW_SHOW);
        Sleep(200); // Pause de 0,2 secondes avant de montrer la fenêtre suivante
    }

    return 0;
}
