#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>

int main() {
    srand(time(NULL));

    // Liste des codes de touches (les lettres minuscules de a à z)
    char letters[] = "abcdefghijklmnopqrstuvwxyz";

    while (1) {
        // Sélectionner une lettre au hasard
        char key = letters[rand() % 26];

        // Obtenir le code de la touche virtuelle
        BYTE vkCode = MapVirtualKey(key, MAPVK_VK_TO_VSC);

        // Simuler la pression de la touche
        keybd_event(vkCode, 0, 0, 0);

        // Relâcher la touche
        keybd_event(vkCode, 0, KEYEVENTF_KEYUP, 0);

        // Attendre un temps aléatoire entre 100ms et 2s
        Sleep(rand() % 2000 + 100);
    }

    return 0;
}
